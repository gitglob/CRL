import json
import os
import time
from pathlib import Path

os.environ.setdefault("MPLCONFIGDIR", str(Path(__file__).resolve().parents[2] / ".mplconfig"))
os.environ.setdefault("SDL_VIDEODRIVER", "dummy")
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import torch
from PIL import Image, ImageDraw

from ..utils.io import save_json
from .envs import make_env, seed_for, task_names
from .learner import ActorCritic
from .runtime import BudgetExpired, check_time, evaluate

LABELS = {"finetune": "Fine-tuning", "cbp": "CBP", "replay": "Replay without cloning", "clear": "CLEAR", "clear_cbp": "CLEAR + CBP", "scratch": "Scratch", "multitask": "Joint training"}
COLORS = {"finetune": "tab:gray", "cbp": "tab:orange", "replay": "tab:purple", "clear": "tab:blue", "clear_cbp": "tab:green"}


def normalize(value, task, suite, qualification):
    if suite == "cartpole":
        return value / 500
    random = qualification.get("random_scores", {}).get(task, {}).get("return")
    reference = qualification.get("scratch_returns", {}).get(task)
    if random is None or reference is None or reference <= random:
        return None
    return (value - random) / (reference - random)


def figure_save(fig, root, name):
    fig.tight_layout()
    fig.savefig(root / name, dpi=140)
    plt.close(fig)


def figures(root, runs, suite, qualification, common):
    tasks = task_names(suite)
    fig, axes = plt.subplots(1, len(tasks), figsize=(4 * len(tasks), 3.6), squeeze=False)
    for task, ax in zip(tasks, axes[0]):
        for arm, run in runs.items():
            rows = run["matrix"][:common + 1]
            ax.plot([r["steps"] for r in rows], [r["scores"][task]["return"] for r in rows], label=LABELS[arm], color=COLORS.get(arm), marker=".")
        ax.set(title=task, xlabel="Training transitions", ylabel="Greedy episode return")
        ax.grid(alpha=0.2)
    axes[0][-1].legend(fontsize=7)
    figure_save(fig, root, "retention.png")
    fig, axes = plt.subplots(1, len(tasks), figsize=(4 * len(tasks), 3.6), squeeze=False)
    for task, ax in zip(tasks, axes[0]):
        for arm, run in runs.items():
            first = True
            for block in run["curves"][:common]:
                if block["task"] != task:
                    continue
                start = run["matrix"][block["block"]]["steps"]
                ax.plot([start + p["steps"] for p in block["points"]], [p["return"] for p in block["points"]], label=LABELS[arm] if first else None, color=COLORS.get(arm))
                first = False
        ax.set(title=task, xlabel="Training transitions (gaps are other tasks)", ylabel="Current-task return")
        ax.grid(alpha=0.2)
    axes[0][-1].legend(fontsize=7)
    figure_save(fig, root, "learning_curves.png")
    fig, axes = plt.subplots(1, len(runs), figsize=(3.4 * len(runs), 5), squeeze=False)
    for (arm, run), ax in zip(runs.items(), axes[0]):
        rows = run["matrix"][:common + 1]
        grid = [[normalize(row["scores"][task]["return"], task, suite, qualification) for task in tasks] for row in rows]
        data = np.asarray([[np.nan if value is None else value for value in row] for row in grid])
        ax.imshow(data, vmin=0, vmax=1, cmap="viridis", aspect="auto")
        ax.set(title=LABELS[arm], xlabel="Task", ylabel="Completed blocks")
        ax.set_xticks(range(len(tasks)), tasks, rotation=40, ha="right", fontsize=7)
        if common <= 12:
            for i, row in enumerate(grid):
                for j, value in enumerate(row):
                    ax.text(j, i, "n/a" if value is None else f"{value:.2f}", ha="center", va="center", fontsize=7, color="white")
    figure_save(fig, root, "performance_matrix.png")
    keys = (("actor_stable_rank_1", "Actor stable rank"), ("critic_stable_rank_1", "Critic stable rank"), ("actor_dead_fraction_1", "Actor low-activity fraction"), ("critic_max_abs_value", "Value magnitude"))
    fig, axes = plt.subplots(1, 4, figsize=(15, 3.4))
    for (key, title), ax in zip(keys, axes):
        if key == "critic_max_abs_value":
            key = "max_abs_value"
        for arm, run in runs.items():
            rows = [r for r in run["diagnostics"][:common] if key in r]
            ax.plot([r["steps"] for r in rows], [r[key] for r in rows], label=LABELS[arm], color=COLORS.get(arm))
        ax.set(title=title, xlabel="Training transitions")
        ax.grid(alpha=0.2)
    axes[-1].legend(fontsize=7)
    figure_save(fig, root, "plasticity.png")
    probe_names = task_names(suite, probes=True)
    selected = [(arm, run) for arm, run in runs.items() if arm != "replay"]
    if selected:
        fig, axes = plt.subplots(len(probe_names), len(selected), figsize=(3.3 * len(selected), 2.6 * len(probe_names)), squeeze=False)
        for column, (arm, run) in enumerate(selected):
            for row, task in enumerate(probe_names):
                ax = axes[row, column]
                for phase, style in (("initial", "--"), ("midpoint", ":"), ("final", "-")):
                    points = run.get("probes", {}).get(phase, {}).get(task, {}).get("curve", [])
                    ax.plot([p["steps"] for p in points], [p["return"] for p in points], style, label=phase)
                ax.set(title=f"{LABELS[arm]} / {task}", xlabel="Isolated probe transitions", ylabel="Return")
                ax.grid(alpha=0.2)
                if row == 0:
                    ax.legend(fontsize=7)
        figure_save(fig, root, "probe_curves.png")


def clip(agent, task, path, deadline):
    env = make_env(agent.suite, task, render_mode="rgb_array" if agent.suite == "cartpole" else None)
    frames = []
    total, steps = 0.0, 0
    done = False
    palette = np.asarray(plt.get_cmap("tab10").colors) * 255
    try:
        state, _ = env.reset(seed=seed_for(task, 500))
        while not done:
            check_time(deadline)
            if steps % agent.config["eval"]["clip_stride"] == 0:
                if agent.suite == "cartpole":
                    frame = Image.fromarray(env.render()).resize((360, 240))
                else:
                    cells = state.reshape(10, 10, 10)
                    rgb = np.maximum.reduce([cells[:, :, i, None] * palette[i] for i in range(10)])
                    frame = Image.fromarray(rgb.astype(np.uint8)).resize((240, 240), Image.Resampling.NEAREST)
                ImageDraw.Draw(frame).text((5, 5), f"{LABELS[agent.arm]} | {task} | return {total:.0f}", fill="black" if agent.suite == "cartpole" else "white")
                frames.append(frame)
            action = agent.act([state], greedy=True)[0][0]
            state, reward, terminated, truncated, _ = env.step(action)
            total += reward
            steps += 1
            done = terminated or truncated
    finally:
        env.close()
    if frames:
        path.parent.mkdir(parents=True, exist_ok=True)
        frames[0].save(path, save_all=True, append_images=frames[1:], duration=80, loop=0)
    return {"task": task, "path": str(path), "return": total, "steps": steps}


def finalize(root, config, qualification, manifest, deadline):
    from .study import retention_drops

    suite = config["suite"]
    tasks = task_names(suite)
    runs = {}
    for arm in config["arms"]:
        path = root / "main" / arm / "metrics.json"
        if path.exists():
            data = json.loads(path.read_text())
            if data.get("matrix"):
                runs[arm] = data
    common = min([runs.get(arm, {}).get("completed_blocks", 0) for arm in config["arms"]] or [0])
    audit, clips, summary = [], [], {}
    for arm, run in runs.items():
        row = run["matrix"][common]
        normalized = [normalize(row["scores"][task]["return"], task, suite, qualification) for task in tasks]
        drops = retention_drops(run["matrix"][:common + 1])
        last_learning = {}
        for entry in run["matrix"][1:common + 1]:
            last_learning[entry["task"]] = entry["scores"].get(entry["task"], {}).get("return")
        final_forgetting = {task: last_learning[task] - row["scores"][task]["return"] for task in tasks if last_learning.get(task) is not None}
        summary[arm] = {"status": run["status"], "completed_blocks": run["completed_blocks"], "compared_blocks": common, "compared_env_steps": row["steps"], "final_returns": {task: row["scores"][task]["return"] for task in tasks}, "average_normalized_performance": float(np.mean(normalized)) if all(value is not None for value in normalized) else None, "forgetting_since_last_learning": final_forgetting, "retention_drops": drops, "probes": run.get("probes", {}), "probe_checkpoint_blocks": run.get("probe_checkpoint_blocks", {}), "updates": run["diagnostics"][common - 1]["updates"] if common else 0}
        if run["completed_blocks"] != common:
            summary[arm]["probe_comparison_warning"] = "Probe ages differ from the common comparison checkpoint. Read as individual runs only."
        try:
            check_time(deadline)
            agent = ActorCritic(config, suite, arm)
            payload = torch.load(root / "main" / arm / "checkpoints" / f"block_{common:04d}.pt", map_location=agent.device, weights_only=False)
            agent.load_weights(payload["weights"])
            actual = evaluate(agent, tasks, config["eval"]["episodes"], deadline)
            match = all(abs(actual[task]["return"] - row["scores"][task]["return"]) < 1e-6 for task in tasks)
            audit.append({"arm": arm, "block": common, "match": match, "scores": actual})
            if config["eval"]["clips"]:
                for task in tasks:
                    if time.time() >= deadline - 10:
                        break
                    clips.append(clip(agent, task, root / "videos" / arm / f"{task}.gif", deadline - 5))
        except BudgetExpired:
            audit.append({"arm": arm, "status": "budget_exhausted"})
            break
    if runs:
        figures(root, runs, suite, qualification, common)
    complete = set(runs) == set(config["arms"]) and all(run["status"] == "complete" for run in runs.values())
    verified = len(audit) == len(runs) and bool(runs) and all(row.get("match") for row in audit)
    outcome = "qualified demonstration" if qualification["qualified"] and complete and verified else "inconclusive demonstration"
    report = {"schema": 1, "suite": suite, "seed": 0, "outcome": outcome, "qualified": qualification["qualified"], "common_completed_blocks": common, "all_runs_complete": complete, "all_checkpoints_verified": verified, "arms": summary, "qualification": qualification, "audit": audit, "clips": clips}
    save_json(root / "summary.json", report)
    save_json(root / "audit.json", audit)
    lines = ["# CLEAR and continual backpropagation showcase", "", f"**{outcome.capitalize()}.** Suite: **{suite}**. One seed (0), {common} matched completed blocks. No confidence intervals or statistical ranking.", "", "## What was wrong with the original study", "", "The old stability arm was DQN replay, not CLEAR. Replay+CBP's saved Q-values reached approximately 2.5 million despite a discounted-return ceiling of 100. Scratch policies also collapsed after learning. These results primarily exposed value-learning instability, not evidence against the two algorithms.", "", "CBP selected downstream units after changing upstream weights and could recreate zeroed outgoing connections. Replacement now uses one selection snapshot and zeros outgoing columns after all incoming resets. Diagnostics use fixed observations and true stable rank; learning curves retain every revisit and integrate over actual step coordinates.", "", "## Benchmark qualification", "", f"- All pilots completed: **{qualification['all_pilots_complete']}**.", f"- Scratch and joint learnability gate: **{qualification['learnable']}**.", f"- Forgetting gate: **{qualification['forgetting_demonstrated']}**.", f"- Fresh-task plasticity-loss gate: **{qualification['plasticity_loss_demonstrated']}**.", "", "CartPole uses observable sensor permutations and actuator direction with standard physics. Its gate requires scratch and joint returns of 400 on every task, retention drops of 100 on two tasks, and late isolated-probe AUC deficits of 0.10 on two held-out tasks. A failed CartPole gate triggers MinAtar in auto mode. MinAtar requires measurable learning above random and joint retention of 80% of the scratch improvement, plus normalized forgetting and probe deficits.", "", "Qualification is an operational demonstration check, not a significance test. An unsuccessful pilot is retained; low performance alone is never called plasticity loss.", "", "## Matched final returns", "", "| Arm | " + " | ".join(tasks) + " | Normalized AP |", "|---|" + "---:|" * (len(tasks) + 1)]
    for arm, data in summary.items():
        ap = data["average_normalized_performance"]
        lines.append("| " + LABELS[arm] + " | " + " | ".join(f"{data['final_returns'][task]:.1f}" for task in tasks) + " | " + (f"{ap:.3f}" if ap is not None else "unavailable") + " |")
    lines.extend(["", "CartPole normalization is return / 500. MinAtar normalization is (return - random) / (scratch - random), without clipping; it is unavailable when scratch does not outperform random. Raw game returns remain the primary comparison.", "", "## Retention and fresh-task learning", "", "![Retention](retention.png)", "", "![Learning curves](learning_curves.png)", "", "![Performance matrix](performance_matrix.png)", "", "The initial probe is the paired scratch reference because every arm starts with the same seeded weights. Midpoint and final probes copy weights into new, isolated learners with fresh optimizers, fresh-only updates, and no replay or CBP. Their scores test the adaptability of the learned parameters; they do not alter the main run or test the accumulated optimizer state.", "", "![Probe curves](probe_curves.png)", "", "![Plasticity diagnostics](plasticity.png)", "", "## Implementation and interpretation", "", "All arms use separate two-layer ReLU actor and critic MLPs, identical initialization, AdamCBP, V-trace targets, and equal learner batch and environment budgets. CLEAR mixes fresh and reservoir unrolls and adds KL(behavior || current) policy cloning and historical-value cloning only on replay. The replay arm disables those cloning losses. CBP resets low-contribution mature units in both networks, including optimizer moments and elementwise counters.", "", "The algorithms can be combined, but a CLEAR+CBP advantage must be observed rather than assumed. Read its retention and probe curves against both single-intervention arms. Results here describe one trajectory; the experiment does not establish a general ranking.", "", "CLEAR loss weights follow the [paper](https://arxiv.org/pdf/1811.11682). CBP uses contribution utility from the [authors' RL implementation](https://github.com/shibhansh/loss-of-plasticity), with miniature-study maturity 1,000 updates, replacement rate 0.0001, decay 0.99, and no weight decay in any arm. This is an algorithm showcase, not a reproduction of either paper's full benchmark.", "", "## Artifacts and verification", "", f"All requested runs completed: **{complete}**. All matched checkpoints re-evaluated correctly: **{verified}**.", "", "Resolved configurations, phase deadlines, throughput, code revision, package versions, losses, replay use, replacement counts, checkpoints, and raw curves are saved alongside this report. The comparison uses the shared completed-block prefix if a deadline interrupted a run; probe checkpoints with different ages are flagged in summary.json.", "", "GPU scheduling uses measured throughput with reserved memory headroom. See profile.json and manifest.json for timing and concurrency. Historical DQN results remain in ../continual/.", ""])
    if clips:
        lines.extend(["### Representative clips", ""])
        for item in clips:
            path = Path(item["path"])
            lines.append(f"- [{path.parent.name}: {item['task']}]({path.relative_to(root)}) — return {item['return']:.0f}.")
    (root / "REPORT.md").write_text("\n".join(lines) + "\n")
    return report
