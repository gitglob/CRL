from copy import deepcopy
import time

import numpy as np
import pytest
import torch

from src.cbp import AdamCBP, FeatureProbe, attach, plasticity
from src.showcase.config import validate
from src.showcase.envs import fixed_observations, make_env, task_names
from src.showcase.learner import ActorCritic, cloning_losses, load_agent, mlp, vtrace
from src.showcase.replay import UnrollReservoir, mix_batch
from src.showcase.runtime import BudgetExpired, Collector, auc, evaluate, learn_rollout, probe_tasks, run_job
from src.showcase.study import qualification, retention_drops
from src.utils.config import load_config
from src.utils.metrics import area_under_curve


@pytest.fixture
def config():
    result = load_config("config/showcase_smoke.yaml")
    result["device"] = "cpu"
    result["train"]["hidden_sizes"] = [8, 8]
    result["train"]["num_envs"] = 4
    result["train"]["batch_unrolls"] = 4
    result["train"]["unroll_length"] = 4
    result["train"]["block_steps"] = 32
    result["train"]["probe_steps"] = 16
    result["clear"]["capacity"] = 32
    result["eval"]["clips"] = False
    return result


def test_vtrace_matches_two_step_on_policy_return_and_detaches():
    reward = torch.tensor([[1.0], [2.0]], requires_grad=True)
    values = torch.tensor([[1.0], [2.0]])
    next_values = torch.tensor([[2.0], [3.0]])
    done = torch.tensor([[False], [True]])
    targets, advantage = vtrace(reward, values, next_values, done, done, torch.zeros_like(values), 0.9)
    torch.testing.assert_close(targets, torch.tensor([[2.8], [2.0]]))
    torch.testing.assert_close(advantage, torch.tensor([[1.8], [0.0]]))
    assert not targets.requires_grad and not advantage.requires_grad


def test_vtrace_clips_importance_weights_and_corrects_replay():
    rewards = torch.tensor([[1.0], [2.0]])
    values = torch.tensor([[1.0], [2.0]])
    next_values = torch.tensor([[2.0], [3.0]])
    done = torch.zeros_like(values, dtype=torch.bool)
    targets, advantages = vtrace(rewards, values, next_values, done, done, torch.full_like(values, np.log(0.5)), 0.9)
    torch.testing.assert_close(targets, torch.tensor([[2.5075], [3.35]]))
    torch.testing.assert_close(advantages, torch.tensor([[1.5075], [1.35]]))
    regular = vtrace(rewards, values, next_values, done, done, torch.zeros_like(values), 0.9)
    clipped = vtrace(rewards, values, next_values, done, done, torch.full_like(values, np.log(9)), 0.9)
    torch.testing.assert_close(regular, clipped)


def test_truncation_bootstraps_final_observation_without_crossing_reset():
    values = torch.zeros(2, 1)
    targets, advantage = vtrace(torch.tensor([[1.0], [100.0]]), values, torch.tensor([[10.0], [9000.0]]), torch.tensor([[False], [True]]), torch.ones(2, 1, dtype=torch.bool), values, 0.9)
    torch.testing.assert_close(targets, torch.tensor([[10.0], [100.0]]))
    torch.testing.assert_close(targets, advantage)


def test_cloning_uses_behavior_to_current_kl_only_on_replay():
    old = torch.tensor([[[0.8, 0.2], [0.1, 0.9]]]).log().requires_grad_()
    current = torch.tensor([[[0.4, 0.6], [0.7, 0.3]]]).log().requires_grad_()
    old_values = torch.tensor([[2.0, 4.0]], requires_grad=True)
    values = torch.tensor([[3.0, 8.0]], requires_grad=True)
    kl, error = cloning_losses(current, values, old, old_values, torch.tensor([True, False]))
    expected = (0.8 * np.log(0.8 / 0.4) + 0.2 * np.log(0.2 / 0.6)) / 2
    assert kl.item() == pytest.approx(expected)
    assert error.item() == pytest.approx(0.5)
    (kl + error).backward()
    assert old.grad is None and old_values.grad is None
    assert current.grad[0, 1].abs().sum() == 0 and values.grad[0, 1] == 0


def test_reservoir_is_bounded_immutable_and_preserves_whole_unrolls():
    reservoir = UnrollReservoir(20, 4, seed=9)
    for step in range(100):
        batch = {"action": np.full((4, 1), step), "behavior_logits": np.full((4, 1, 2), step, dtype=np.float32)}
        reservoir.add(batch)
        batch["action"][:] = -1
    assert reservoir.seen == 100 and len(reservoir.items) == 5
    kept = [item["action"][0] for item in reservoir.items]
    assert min(kept) < 50 and max(kept) > 50
    for item in reservoir.items:
        assert np.all(item["action"] == item["behavior_logits"][:, 0])
        assert len(set(item["action"].tolist())) == 1


def test_zero_replay_preserves_batch_and_sampling_rng():
    rng = np.random.default_rng(2)
    before = deepcopy(rng.bit_generator.state)
    fresh = {"action": np.zeros((4, 4), dtype=np.int64)}
    memory = UnrollReservoir(32, 4)
    memory.add(fresh)
    actual, mask = mix_batch(fresh, memory, 0, rng)
    assert actual is fresh and not mask.any() and rng.bit_generator.state == before


def test_simultaneous_cbp_resets_cannot_resurrect_outgoing_columns():
    net = mlp(4, [3, 3], 2)
    probe = FeatureProbe(net)
    cbp = attach(probe, {"decay_rate": 0.99, "replacement_rate": 0.34, "maturity_threshold": 0, "utility": "contribution"}, torch.Generator().manual_seed(2))
    optimizer = AdamCBP(net.parameters())
    probe.capturing = True
    net(torch.ones(8, 4)).sum().backward()
    probe.capturing = False
    optimizer.step()
    assert cbp.step(optimizer, probe.features) == [1, 1]
    first = torch.where(cbp.state[0]["age"] == 0)[0]
    second = torch.where(cbp.state[1]["age"] == 0)[0]
    assert torch.count_nonzero(net[2].weight[:, first]) == 0
    assert torch.count_nonzero(net[4].weight[:, second]) == 0
    for key in ("step", "exp_avg", "exp_avg_sq"):
        assert torch.count_nonzero(optimizer.state[net[2].weight][key][:, first]) == 0
        assert torch.count_nonzero(optimizer.state[net[2].weight][key][second]) == 0


def test_cbp_utilities_are_computed_before_any_replacement():
    net = mlp(4, [3, 3], 2)
    original = deepcopy(net[2].weight.detach())
    probe = FeatureProbe(net)
    cbp = attach(probe, {"decay_rate": 0.99, "replacement_rate": 0.34, "maturity_threshold": 0}, torch.Generator().manual_seed(2))
    observed = []
    select = cbp.select

    def capture(state, utility):
        observed.append(net[2].weight.detach().clone())
        return select(state, utility)

    cbp.select = capture
    cbp.step(None, [torch.ones(8, 3), torch.ones(8, 3)])
    assert len(observed) == 2
    for value in observed:
        torch.testing.assert_close(value, original)


def test_true_stable_rank_differs_from_singular_value_participation_ratio():
    features = torch.tensor([[6.0, 3.0], [0.0, 3.0], [3.0, 4.0], [3.0, 2.0]])
    report = plasticity(mlp(2, [2], 1), [features], 0.025)
    assert report["stable_rank_0"] == pytest.approx(10 / 9)
    assert report["singular_value_participation_ratio_0"] == pytest.approx(1.6)


@pytest.mark.parametrize("left,right,change", [("finetune", "cbp", "replacement"), ("clear", "clear_cbp", "replacement"), ("finetune", "clear", "replay"), ("replay", "clear", "cloning")])
def test_disabled_interventions_are_exact_equivalences(config, left, right, change):
    if change == "replacement":
        config["cbp"]["replacement_rate"] = 0
    elif change == "replay":
        config["clear"]["replay_ratio"] = 0
    else:
        config["clear"]["policy_cloning_weight"] = 0
        config["clear"]["value_cloning_weight"] = 0
    agents = [ActorCritic(config, "cartpole", arm) for arm in (left, right)]
    collectors = [Collector(agent, ["identity"]) for agent in agents]
    try:
        for _ in range(4):
            for agent, collector in zip(agents, collectors):
                learn_rollout(agent, collector.collect(float("inf")))
        for first, second in zip(agents[0].parameters, agents[1].parameters):
            torch.testing.assert_close(first, second, rtol=0, atol=0)
    finally:
        for collector in collectors:
            collector.close()


def test_probe_training_and_diagnostics_leave_parent_unchanged(config):
    agent = ActorCritic(config, "cartpole", "clear_cbp")
    collector = Collector(agent, ["identity"])
    learn_rollout(agent, collector.collect(float("inf")))
    collector.close()
    before = deepcopy(agent.checkpoint())
    fixed = fixed_observations("cartpole", 32)
    first = agent.diagnostics(fixed)
    probe_tasks(agent, time.time() + 20, "test")
    second = agent.diagnostics(fixed)
    assert first == second
    for net in ("actor", "critic"):
        for name, parameter in agent.weights()[net].items():
            torch.testing.assert_close(parameter, before["weights"][net][name], rtol=0, atol=0)
    assert agent.memory.seen == before["memory"]["seen"] and agent.updates == before["updates"]
    assert torch.equal(agent.action_rng.get_state(), before["action_rng"])


@pytest.mark.parametrize("suite", ["cartpole", "minatar"])
def test_task_interfaces_and_fixed_diagnostic_inputs(suite):
    for task in task_names(suite) + task_names(suite, True):
        env = make_env(suite, task)
        state, _ = env.reset(seed=0)
        assert state.shape == (21 if suite == "cartpole" else 1000,)
        assert env.action_space.n == (2 if suite == "cartpole" else 6)
        env.step(0)
        env.close()
    np.testing.assert_array_equal(fixed_observations(suite, 32), fixed_observations(suite, 32))


def test_context_makes_reversed_actions_observably_distinct():
    normal, reversed_env = make_env("cartpole", "identity"), make_env("cartpole", "identity_reverse")
    a, _ = normal.reset(seed=3)
    b, _ = reversed_env.reset(seed=3)
    np.testing.assert_array_equal(a[:4], b[:4])
    assert a[-1] == 1 and b[-1] == -1
    np.testing.assert_array_equal(normal.step(0)[0][:4], reversed_env.step(1)[0][:4])
    normal.close()
    reversed_env.close()


def test_auc_integrates_irregular_coordinates():
    points = [{"steps": 0, "return": 0}, {"steps": 1, "return": 1}, {"steps": 10, "return": 1}]
    assert auc(points) == pytest.approx(0.95)
    legacy = [{"block": 0, "block_steps": row["steps"], "normalized": row["return"]} for row in points]
    assert area_under_curve(legacy, 0) == pytest.approx(0.95)


def test_revisit_forgetting_uses_previous_learning_block():
    rows = []
    for block, (task, a, b) in enumerate((("a", 500, 10), ("b", 100, 500), ("a", 450, 200), ("b", 300, 480))):
        rows.append({"block": block, "task": task, "scores": {"a": {"return": a}, "b": {"return": b}}})
    drops = retention_drops(rows)
    assert [r["drop"] for r in drops if r["task"] == "a"] == [400, 150]
    assert [r["since_block"] for r in drops if r["task"] == "a"] == [0, 2]


def test_incomplete_or_unlearnable_pilot_cannot_qualify():
    report = qualification("cartpole", {}, {})
    assert not report["qualified"] and not report["learnable"]


def test_checkpoint_restores_behavior_optimizer_memory_and_cbp(config, tmp_path):
    agent = ActorCritic(config, "cartpole", "clear_cbp")
    collector = Collector(agent, ["identity"])
    batch = collector.collect(float("inf"))
    agent.optimize(batch)
    collector.close()
    path = tmp_path / "model.pt"
    torch.save(agent.checkpoint(), path)
    restored, _ = load_agent(path, device="cpu")
    agent.optimize(batch)
    restored.optimize(batch)
    for first, second in zip(agent.parameters, restored.parameters):
        torch.testing.assert_close(first, second, rtol=0, atol=0)
    states = fixed_observations("cartpole", 4)
    np.testing.assert_array_equal(agent.act(states)[0], restored.act(states)[0])


def test_complete_job_retains_all_revisit_curves_and_can_be_audited(config, tmp_path):
    job = {"config": config, "suite": "cartpole", "arm": "clear_cbp", "blocks": ["identity", "identity_reverse", "identity"], "out": str(tmp_path), "deadline": time.time() + 30, "probes": True}
    result = run_job(job)
    assert result["status"] == "complete"
    import json

    metrics = json.loads((tmp_path / "metrics.json").read_text())
    assert len(metrics["curves"]) == 3 and metrics["completed_blocks"] == 3
    assert set(metrics["probes"]) == {"initial", "midpoint", "final"}
    agent, _ = load_agent(tmp_path / "model.pt", device="cpu")
    assert evaluate(agent, task_names("cartpole"), 1) == metrics["matrix"][-1]["scores"]


def test_expired_job_is_incomplete_and_never_claims_a_checkpoint(config, tmp_path):
    result = run_job({"config": config, "suite": "cartpole", "arm": "finetune", "out": str(tmp_path), "deadline": time.time() - 1})
    assert result["status"] == "budget_exhausted" and result["completed_blocks"] == 0
    assert not (tmp_path / "model.pt").exists()


def test_new_configs_validate_and_limit_the_experiment_to_one_hour():
    for path in ("config/showcase.yaml", "config/showcase_smoke.yaml"):
        validate(load_config(path))
    config = load_config("config/showcase.yaml")
    config["max_seconds"] = 3601
    with pytest.raises(ValueError, match="3600"):
        validate(config)


def test_collector_stores_truncated_final_observation_before_reset(config, monkeypatch):
    class AlwaysTruncated:
        def reset(self, **kwargs):
            return np.full(21, -2, dtype=np.float32), {}

        def step(self, action):
            return np.full(21, 7, dtype=np.float32), 1.0, False, True, {}

        def close(self):
            pass

    monkeypatch.setattr("src.showcase.runtime.make_env", lambda *args: AlwaysTruncated())
    collector = Collector(ActorCritic(config, "cartpole", "finetune"), ["identity"])
    batch = collector.collect(float("inf"))
    assert np.all(batch["observation"] == -2) and np.all(batch["next_observation"] == 7)
    assert batch["boundary"].all() and not batch["terminated"].any()
    collector.close()


def test_interrupted_probe_retains_partial_curve(config, monkeypatch):
    agent = ActorCritic(config, "cartpole", "finetune")
    calls = 0
    original = evaluate

    def interrupt(*args, **kwargs):
        nonlocal calls
        calls += 1
        if calls == 2:
            raise BudgetExpired()
        return original(*args, **kwargs)

    monkeypatch.setattr("src.showcase.runtime.evaluate", interrupt)
    results = {}
    with pytest.raises(BudgetExpired):
        probe_tasks(agent, time.time() + 10, "interrupted", results)
    partial = results[task_names("cartpole", True)[0]]
    assert partial["status"] == "incomplete" and partial["auc"] is None
    assert len(partial["curve"]) == 1 and partial["train_env_steps"] > 0
